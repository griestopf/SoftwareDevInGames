#ifndef MESHINSTANCE3D_H
#define MESHINSTANCE3D_H

#include <iostream>

#include "node3d.h"

class Visitor;

class MeshInstance3D : public Node3D
{
public:
    MeshInstance3D();
    MeshInstance3D(const std::string &new_name);
    ~MeshInstance3D();

private:
    // TODO hold a Mesh reference
};

#endif // MESHINSTANCE3D_H

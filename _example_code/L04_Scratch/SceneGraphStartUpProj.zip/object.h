#ifndef OBJECT_H
#define OBJECT_H

#include <string>

class Object {
public:
    Object();
    Object(const std::string &new_name);
    ~Object();

    std::string getName() const;
    void setName(const std::string &new_name);
private:
    std::string name;
};  


#endif // OBJECT_H